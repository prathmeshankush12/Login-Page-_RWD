function func(){
    var user= document.getElementById("Username").value;
   var pass= document.getElementById("Password").value;
   if (user=='ankushprathmesh76666@gmail.com' && pass == '123456789' ){
     alert("Login Successfully!")
    window.location.assign("s_Login.html")
   }
   else{
     alert("Login Invalid !!")
   }
}




 
